# ComCody Tetris Creator Pack v2

Import this ZIP in ComCody with **Packs → Import**.

## What you get

- A playable Tetris Lite game template.
- Real `piece.yaml`, `piece.js`, and `tests.yaml` files for reusable blocklys.
- A bundle story so creators understand what to reuse and why.
- A reuse path for Wood Block Puzzle and other grid-placement games.

## No hidden wheel reinvention

Gravity is assembled from existing pieces:

```text
Loop count 1
  Face Down
  Move
```

Touch controls are assembled too:

```text
Swipe Left  = Face Left + Move
Swipe Right = Face Right + Move
Swipe Down  = Face Down + Move
Tap         = Rotate Shape
```

Only pieces missing from Maze are included as reusable primitives: shape spawn, rotate shape, lock shape, clear full rows, and line-clear scoring.
