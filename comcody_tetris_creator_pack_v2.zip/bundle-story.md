# Tetris Creator Pack v2

A playable falling-block game built from reusable ComCody pieces.

## Core rule

A full line is a full line. Manual walls, locked Tetris pieces, temporary blocks, or future Wood Block Puzzle blocks all count as occupied cells.

## Reuse

- `Clear Full Rows` is reusable for Tetris, Wood Block Puzzle rows, and any grid puzzle with full-line clearing.
- `Score Line Clear` scores from the shared `lastClearRows` result.
- `Lock Shape` turns the active piece into occupied grid cells.
- `Face Direction + Move` remains shared movement composition.
