# Wood Block Puzzle Reuse Notes

The current Tetris pack already contains useful grid-game primitives.

Reuse directly:

- Lock Shape as place shape.
- Clear Full Rows as the starting line-clear mechanic.
- Score Line Clear as row or combo reward.

Extend next:

- Clear Full Rows should become Clear Full Lines to support rows and columns.
- Next Shape should become Shape Tray with three selectable pieces.
- Gravity Loop is not needed for Wood Block Puzzle.
