export async function run(ctx, piece) {
  await ctx.spawnRandomPiece()
}
