# Next Shape

**Next Shape**

## Game story

Create a new active grid shape from the shape tray.

## Used in

Tetris starts, respawns after lock, shape-tray games.

## Reuse or extend

Reuse in falling-block games or adapt the source for Wood Block Puzzle tray refill.

## Tags

spawn, shape, tetris, wood block puzzle, reusable
