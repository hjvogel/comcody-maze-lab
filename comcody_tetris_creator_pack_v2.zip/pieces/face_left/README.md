# Face Left

**Aim Left**

## Game story

Point the active shape left before using Move.

## Used in

Swipe left, keyboard left, grid puzzles.

## Reuse or extend

Pair with Move to build left movement without adding new movement code.

## Tags

direction, move, tetris, grid puzzle, reusable
