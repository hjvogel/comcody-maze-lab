# Rotate Shape

**Spin Shape**

## Game story

Rotate the active shape only when it still fits the grid.

## Used in

Tetris tap rotate, shape puzzles with rotatable pieces.

## Reuse or extend

Bind to tap, keyboard, or a rule block. Wood Block Puzzle can omit or keep it as an optional power move.

## Tags

rotate, shape, tetris, grid puzzle, reusable
