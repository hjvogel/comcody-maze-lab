// ComCody shared line-clear primitive.
// Important rule: a filled line is based on occupied grid cells, not piece type.
// Manual walls/paint blocks, locked falling pieces, and temporary blocks all count.
export async function run(ctx, piece) {
  if (ctx.clearFullRowsAnyOccupied) {
    piece.lastClearRows = await ctx.clearFullRowsAnyOccupied({ score: true })
    return piece.lastClearRows
  }
  if (ctx.clearRows) {
    // ComCody v57+ clearRows follows the same any-occupied rule.
    piece.lastClearRows = await ctx.clearRows({ occupancy: 'any' })
    return piece.lastClearRows
  }

  const grid = ctx.grid || ctx.board || {}
  const cols = grid.cols ?? grid.width ?? ctx.cols
  const rows = grid.rows ?? grid.height ?? ctx.rows
  const key = (x, y) => `${x},${y}`
  const locked = new Map(Object.entries(ctx.lockedCells || ctx.locked || {}))
  const walls = new Set(ctx.walls || ctx.manualBlocks || ctx.blockedCells || [])
  const temp = new Set(ctx.temporaryCells || [])
  const occupied = (x, y) => locked.has(key(x, y)) || walls.has(key(x, y)) || temp.has(key(x, y))

  const full = []
  for (let y = 0; y < rows; y++) {
    let isFull = true
    for (let x = 0; x < cols; x++) {
      if (!occupied(x, y)) { isFull = false; break }
    }
    if (isFull) full.push(y)
  }
  piece.lastClearRows = full.length
  if (ctx.setLastClearRows) ctx.setLastClearRows(full.length)
  return full.length
}
