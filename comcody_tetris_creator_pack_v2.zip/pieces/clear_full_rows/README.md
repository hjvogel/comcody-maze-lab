# Clear Full Rows

Hook: **Clear Lines**

Game story: when a row is completely filled, it disappears and points are awarded.

Reuse rule: this piece does **not** care what created the occupied cells. Manual walls, locked falling pieces, temporary blocks, and future puzzle blocks all count the same.

Reuse path: Tetris clears rows. Wood Block Puzzle can reuse this as the row half of a row/column clear piece.
