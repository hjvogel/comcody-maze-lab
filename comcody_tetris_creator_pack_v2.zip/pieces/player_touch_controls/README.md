# Swipe Controls

**Swipe Play**

## Game story

Map player gestures to visible child-piece chains.

## Used in

Tablet Tetris, maze touch play, arcade puzzle controls.

## Reuse or extend

Keep inputs readable. Swipe left equals Face Left plus Move, not hidden movement code.

## Tags

input, tablet, touch, controls, reusable
