# Face Down

**Aim Down**

## Game story

Point the active shape downward before using Move.

## Used in

Tetris gravity, swipe down, falling block puzzles.

## Reuse or extend

Pair with Move to build gravity, soft drop, or downward placement rules.

## Tags

direction, move, tetris, grid puzzle, reusable
