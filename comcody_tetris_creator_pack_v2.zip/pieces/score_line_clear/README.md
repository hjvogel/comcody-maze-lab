# Score Line Clear

**Score Lines**

## Game story

Reward each cleared line with visible score.

## Used in

Tetris, Wood Block Puzzle rows or columns, arcade combo rewards.

## Reuse or extend

Change points or reason. Reuse for rows, columns, combos, or level goals.

## Tags

score, reward, line clear, combo, reusable
