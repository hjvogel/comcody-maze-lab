export async function run(ctx, piece) {
  await ctx.score(piece.reason ?? 'line_clear', piece.points ?? 100)
}
