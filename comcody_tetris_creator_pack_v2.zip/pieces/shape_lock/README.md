# Lock Shape

**Place Shape**

## Game story

Turn the moving active shape into occupied board cells.

## Used in

Tetris landing, Wood Block Puzzle placement, any grid occupancy game.

## Reuse or extend

Reuse when a piece should become part of the board after move, drop, or drag-place.

## Tags

lock, place, grid, occupancy, wood block puzzle, reusable
