# Face Right

**Aim Right**

## Game story

Point the active shape right before using Move.

## Used in

Swipe right, keyboard right, grid puzzles.

## Reuse or extend

Pair with Move to build right movement without adding new movement code.

## Tags

direction, move, tetris, grid puzzle, reusable
