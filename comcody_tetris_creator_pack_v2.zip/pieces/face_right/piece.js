export async function run(ctx, piece) {
  await ctx.face(1)
}
