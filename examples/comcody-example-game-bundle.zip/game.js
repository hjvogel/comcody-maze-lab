export async function run(ctx, game) {
  await ctx.runProgram(game.program)
}
