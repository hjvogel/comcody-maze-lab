export async function run(ctx, piece) {
  await ctx.move(piece.steps ?? 2)
}
