# Dash 2 ComCody Piece

A minimal real ComCody Pack v1 piece. It imports as a no-code block and carries real JavaScript under Expert Code.
